# Campo Grande · Zona de Quarentena

Sobrevivência isométrica nas ruas de Campo Grande, Mato Grosso do Sul.

[**Jogar no navegador ou no celular**](https://contato673.github.io/CASO-ABERTO-GPT/) · [Versão Windows](versoes/Caso-Aberto-Windows.zip) · [Capturas de teste](testes-visuais/sobrevivencia/)

Na primeira abertura de cada nova publicação, crie seu sobrevivente e leia o bilhete de Bia. Cada versão começa do zero e usa seu próprio save. Ao recarregar a mesma versão, você continua de onde parou. Em um jogo novo, a história começa perto do Posto Barão, na Rua Barão do Rio Branco. A primeira missão pede um kit de primeiros socorros na Pague Menos da Rua 13 de Maio. O minimapa marca o destino. Em locais trancados, quebrar um vidro libera a busca e alerta infectados próximos.

| Controle | Ação |
| --- | --- |
| WASD, setas ou joystick | Caminhar ou dirigir |
| E, tocar na construção próxima ou botão de interação | Ver o estoque externo ou falar no abrigo |
| F ou Roubar / Entrar / Descer | Assumir um carro próximo ou sair dele com o veículo parado |
| Espaço ou mira na tela | Atacar com o equipamento disponível |
| I ou ícone da mochila | Ver suprimentos, usar itens e trocar a arma na mão |
| Esc ou Fechar | Fechar a janela |

Saúde, fome, sede e energia afetam recuperação e movimento. A mochila tem 18 espaços. O saque varia por categoria de construção e volta entre 2 e 6 horas reais depois que o estoque é esvaziado. A contagem continua com o jogo fechado. Os carros consomem combustível. Estacione e chegue perto do carro em uso para abastecer. O motor e a quebra de vidro podem chamar infectados.

Na mochila, escolha **Equipar** ou **Guardar arma · Usar punhos**. A faca aparece no Mercadão, e a pistola e a munição podem ser encontradas no Pátio Central Shopping. Cada disparo gasta uma munição e pode atrair infectados de longe.

Para vasculhar uma casa, aproxime-se da fachada e use o botão de interação. Se estiver trancada, quebrar o vidro chama a atenção dos infectados. Dentro do menu de esconderijo você pode descansar, lavar as mãos, trocar de roupa e sair por uma janela quando houver espaço livre. As roupas vêm do saque e aparecem no personagem, inclusive depois de recarregar o jogo.

Os quadradinhos verdes no minimapa indicam carros próximos. Os encontros com sobreviventes são raros. Alguns fogem dos infectados e conversam com você, enquanto outros atacam. O minimapa mostra vias, carros e o objetivo ativo. Os infectados têm animações de caminhada e sons que vêm da posição deles na rua.

Perto do Posto Barão, procure **Sua casa**, indicada pelo ícone azul no minimapa. Entre a pé para descansar e abrir o baú pessoal de 60 itens. O conteúdo do baú permanece após a derrota. No menu **Mobiliar**, use duas peças da mochila para montar um móvel e depois escolha onde colocá-lo. Móveis e aparência ficam salvos.

A campanha **A última transmissão** tem 16 missões de busca, entrega e reconhecimento. Os quatro contratos de abastecimento depois da campanha podem ser repetidos após 20 minutos. O diário está disponível na mochila, no Posto Barão e em casa. Mochila, necessidades, estoque, carros e reputação são salvos no dispositivo. A rede do abrigo é uma progressão local para um jogador.

## Editar

1. Com a cópia original em mãos, copie **assets/pack/** para o mesmo caminho deste projeto.
2. Importe **project.godot** no Godot 4.7.2.
3. Os recursos opcionais de sobrevivência ficam em **assets/survival_local/**, ignorados pelo Git. Os créditos e a origem de cada pack estão na [revisão](REVISAO.md).
4. Use os presets **Windows** e **Web** nos templates da mesma versão. Para publicar o Web, atualize os arquivos da pasta **docs/** e o ZIP em **versoes/**.

Dados cartográficos © [OpenStreetMap contributors](https://www.openstreetmap.org/copyright), sob ODbL.

## Alpha cooperativo

A versão do GitHub Pages inicia a campanha individual. O serviço do alpha abre o jogo em **/alpha/** e exige conta. Só há dez convites de uso único. Um WebSocket autenticado compartilha posição, infectados, dano e distrações sonoras entre os jogadores. Senhas com salt e hash scrypt e sessões com expiração ficam no PostgreSQL privado da infraestrutura. Inventário, casa e campanha são locais, separados por conta e por publicação. O saque e os veículos ainda têm estado individual neste alpha.

No celular, o botão pontilhado abre a roda de itens. No teclado, use **Q**. As habilidades têm XP por prática e por estudo, com vantagem inicial da profissão. A fabricação mostra materiais, ferramenta, bancada e nível exigidos em cada receita. A bancada fica na casa.

O arquivo `render.yaml` define o serviço com WebSocket e seu PostgreSQL. O caminho de saúde é `/health`. Em desenvolvimento local, `ALPHA_LOCAL_DEV=1` permite usar um banco isolado apontado por `ALPHA_SQLITE`. A implantação externa exige `DATABASE_URL` e os hashes de convites. Para criar outros convites, use códigos aleatórios de alta entropia e inclua apenas seus hashes SHA-256 em `ALPHA_INVITE_HASHES`. Na implantação use a mesma origem para a página, o login e o WebSocket.
